mysql -uroot < base/db_create.sql
mysql -uroot < base/mt2_user_c.sql
mysql -uroot account < account.sql
mysql -uroot common < common.sql
mysql -uroot log < log.sql
mysql -uroot player < player.sql
